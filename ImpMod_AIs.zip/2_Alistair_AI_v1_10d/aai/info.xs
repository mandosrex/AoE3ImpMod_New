void sendInformationalNotes(void)
{
    string note = "Alternative ImpMod AI v1.10d\n\n";
    switch(aiGetWorldDifficulty())
    {
        case cDifficultySandbox:
        {
            note = note + "Sandbox difficulty: AIs are slowed down by 50%.";
            break;
        }
        case cDifficultyEasy:
        {
            note = note + "Easy difficulty: AIs are slowed down by 25%.";
            break;
        }
        case cDifficultyModerate:
        {
            note = note + "Moderate difficulty: all players are equal.";
            break;
        }
        case cDifficultyHard:
        {
            note = note + "Hard difficulty: AIs are sped up by 25% and are given a small resource tricle.";
            break;
        }
        case cDifficultyExpert:
        {
            note = note + "Expert difficulty: AIs are sped up by 50% and are given a small resource tricle.";
            break;
        }
        default:
        {
            break;
        }
    }
}

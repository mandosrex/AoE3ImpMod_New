//==============================================================================
/* 
   age3x05p02.xs
   
   Battle of the Little Bighorn - Reno's AI

   This is a standard AI.  Major AI enemy.
*/
//==============================================================================



include "aiHeaderCampaign.xs";     // Gets global vars, function forward declarations
include "aiMainCampaign.xs";       // The bulk of the AI



//==============================================================================
/*	preInit()

	This function is called in main() before any of the normal initialization 
	happens.  Use it to override default values of variables as needed for 
	personality or scenario effects.
*/
//==============================================================================
void preInit(void)
{
	aiEcho("preInit() starting.");
	cvMaxAge = cAge4;                // AI is capped at Age4.
	cvOkToBuildWalls = false;        // He already has the walls I gave him.
	cvOkToFortify = true;            // Okay to build Outposts if he wants to.
	cvOkToBuildForts = true;         // AI can make forts whenever he wants.
   cvOkToGatherNuggets = false;     // More fun for the player.
   cvOkToAllyNatives = false;       // Not for Custer to have Cheyenne allies at the Battle of Little Big Horn.

   btRushBoom = 1.00;               // RUSH!!
   btOffenseDefense = 1.0;          // Very aggressive.
}

//==============================================================================
/*	postInit()

	This function is called in main() after the normal initialization is 
	complete.  Use it to override settings and decisions made by the startup logic.
*/
//==============================================================================
void postInit(void)
{
   aiEcho("postInit() starting.");
   switch(aiGetWorldDifficulty())
   {
      case cDifficultyEasy:
      {
         kbSetPlayerHandicap(cMyID, kbGetPlayerHandicap(cMyID)*0.90);
         break;
      }
      case cDifficultyModerate:
      {
         kbSetPlayerHandicap(cMyID, kbGetPlayerHandicap(cMyID)*1.00);
         break;
      }
      case cDifficultyHard:
      {
         kbSetPlayerHandicap(cMyID, kbGetPlayerHandicap(cMyID)*1.10);
         break;
      }
      case cDifficultyExpert:
      {
         kbSetPlayerHandicap(cMyID, kbGetPlayerHandicap(cMyID)*1.20);
         break;
      }
   }
}


//==============================================================================
/*	Rules

	Add personality-specific or scenario-specific rules in the section below.
*/
//==============================================================================


